package com.cs360.andrewmcpherson_inventoryapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.app.Activity;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.MyViewHolder> {
    Context context;
    ArrayList<String> name_id;
    ArrayList<String> quantity_id;
    DBHelperInventory db;



    public ItemAdapter(Context context, ArrayList<String> name_id, ArrayList<String> quantity_id, DBHelperInventory db) {
        this.db = db;
        this.context = context;
        this.name_id = name_id;
        this.quantity_id = quantity_id;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.inventoryentry, parent, false);
        return new MyViewHolder(v);

    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.name_id.setText(String.valueOf(name_id.get(position)));
        holder.quantity_id.setText(String.valueOf(quantity_id.get(position)));
    }

    @Override
    public int getItemCount() {
        return name_id.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView name_id;
        TextView quantity_id;
        Button delete;
        public MyViewHolder(@NonNull View view) {
            super(view);
            name_id = view.findViewById(R.id.textName);
            quantity_id = view.findViewById(R.id.textQuantity);
            delete = (Button) view.findViewById(R.id.deleteItem);
            //final int pos = position;
            String s = quantity_id.getText().toString().trim();
            if (s.equals("0")) {
                InventoryActivity.sendSMS(context.getApplicationContext());
            }



        }
    }
}
