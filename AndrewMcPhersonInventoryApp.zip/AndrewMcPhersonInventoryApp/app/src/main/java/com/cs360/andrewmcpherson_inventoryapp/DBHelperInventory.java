package com.cs360.andrewmcpherson_inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class DBHelperInventory extends SQLiteOpenHelper {
    public DBHelperInventory(Context context) {
        super(context, "InventoryData.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase DB) {
        //create Table inventory(id INTEGER primary key autoincriment NOT NULL, name TEXT, quantity TEXT)
        DB.execSQL("create Table inventory(name TEXT primary key, quantity TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase DB, int i, int i1) {
        DB.execSQL("drop Table if exists inventory");
    }

    public Boolean insertInventoryData(String name, String quantity){
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", name);
        contentValues.put("quantity", quantity);
        long result = DB.insert("inventory", null, contentValues);
        return result != -1;
    }
    public Cursor getdata() {
        SQLiteDatabase DB = this.getWritableDatabase();
        return DB.rawQuery("Select * from inventory", null);
    }
    /*
    public int update(String name ?? int id) {
                //reminder if using id contentValues.put(id)
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", name);
        contentValues.put("quantity", quantity);
        return DB.update("inventory", contentValues, "name = ?", new String[] {string.valueOf(name)})
        }
     */
   public Boolean deleteInventoryData(String name) {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from inventory where name = ?", new String[] {name});
        if(cursor.getCount()>0) {
            long result = DB.delete("inventory", "name=?", new String[] {name});
            if(result==-1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }
    public Boolean editInventoryData(String name, String quantity) {
       SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", name);
        contentValues.put("quantity", quantity);
        long result = DB.update("inventory",contentValues, "name=?", new String[] {name});
        return result != -1;

    }
    /*public void del(int i) {
       SQLiteDatabase DB = this.getWritableDatabase();
       DB.delete("inventory", i+ " = ?", new String[] {String.valueOf(i)});
    }
    public void dd(String i) {
        SQLiteDatabase DB = this.getWritableDatabase();
        DB.delete("inventory", i+ " = ?", new String[] {String.valueOf(i)});
    }*/
}
