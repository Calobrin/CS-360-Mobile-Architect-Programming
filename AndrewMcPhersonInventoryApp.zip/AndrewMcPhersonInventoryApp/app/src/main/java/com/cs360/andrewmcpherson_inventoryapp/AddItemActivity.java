package com.cs360.andrewmcpherson_inventoryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddItemActivity extends AppCompatActivity {

    EditText name, quantity;
    Button add, edit, delete;
    DBHelperInventory DBI;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        name = findViewById(R.id.textItemNameInput);
        quantity = findViewById(R.id.textItemQuantityInput);
        add = findViewById(R.id.addItem);
        edit = findViewById(R.id.editItem);
        delete = findViewById(R.id.deleteItem);

        DBI = new DBHelperInventory(this);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nameTXT = name.getText().toString();
                String quantityTXT = quantity.getText().toString();

                Boolean checkinsertdata = DBI.insertInventoryData(nameTXT, quantityTXT);
                if (checkinsertdata == true) {
                    Toast.makeText(AddItemActivity.this, "Item has been added", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(AddItemActivity.this, InventoryActivity.class));
                } else {
                    Toast.makeText(AddItemActivity.this, "Item was not added, enter both fields", Toast.LENGTH_SHORT).show();
                }
            }
        });
        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nameTXT = name.getText().toString();
                String quantityTXT = quantity.getText().toString();

                Boolean checkeditdata = DBI.editInventoryData(nameTXT, quantityTXT);
                if (checkeditdata) {
                    Toast.makeText(AddItemActivity.this, "Item has been edited", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(AddItemActivity.this, InventoryActivity.class));
                } else {
                    Toast.makeText(AddItemActivity.this, "Item was not edited, check entered fields", Toast.LENGTH_SHORT).show();
                }
            }
        });
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nameTXT = name.getText().toString();
                Boolean checkdeletedata = DBI.deleteInventoryData(nameTXT);
                if (checkdeletedata) {
                    Toast.makeText(AddItemActivity.this, "Item has been deleted", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(AddItemActivity.this, InventoryActivity.class));
                } else {
                    Toast.makeText(AddItemActivity.this, "Item was not deleted, check entered fields", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}