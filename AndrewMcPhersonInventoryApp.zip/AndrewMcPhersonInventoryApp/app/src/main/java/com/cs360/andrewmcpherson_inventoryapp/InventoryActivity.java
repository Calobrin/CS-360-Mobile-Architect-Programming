package com.cs360.andrewmcpherson_inventoryapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class InventoryActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    ArrayList<String> name;
    ArrayList<String> quantity;
    DBHelperInventory DBI;
    ItemAdapter adapter;
    Button delete, AddEditDelete;
    ImageButton sms;
    Context context;
    Activity activity;

    private final int MY_PERMISSIONS_REQUEST_SEND_SMS = 0;
    private static boolean smsauth = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);
        AddEditDelete = findViewById(R.id.AddEditDelete);
        delete = findViewById(R.id.deleteItem);
        DBI = new DBHelperInventory(this);
        name = new ArrayList<>();
        quantity = new ArrayList<>();
        sms = findViewById(R.id.img_btnNotifications);
        recyclerView = findViewById(R.id.recyclerview);
        adapter = new ItemAdapter(this, name, quantity, DBI);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        context = this;
        activity = this;

        displayData();

        AddEditDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(InventoryActivity.this, AddItemActivity.class));
            }
        });

        sms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS)!= PackageManager.PERMISSION_GRANTED) {
                    //Log.d(TAG, getString(R.string.permission_not_granted));
                    //ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.SEND_SMS},MY_PERMISSIONS_REQUEST_SEND_SMS);
                    if (ActivityCompat.shouldShowRequestPermissionRationale(activity, Manifest.permission.SEND_SMS)) {
                        //requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, MY_PERMISSIONS_REQUEST_SEND_SMS)) {
                        Toast.makeText(activity, "Permissions are disabled", Toast.LENGTH_SHORT).show();
                    } else {
                        ActivityCompat.requestPermissions(activity, new String[]{Manifest.permission.SEND_SMS}, MY_PERMISSIONS_REQUEST_SEND_SMS);
                    }
                } else {
                    Toast.makeText(activity, "Permissions are enabled", Toast.LENGTH_SHORT).show();
                    //Log.d(TAG, getString(R.string.permission_granted));

                }
                //Intent intent = new Intent(getApplicationContent(),.class);
                //startActivity(intent);

                startActivity(new Intent(InventoryActivity.this, PermissionActivity.class));
            }
        });

    }

    private void displayData() {
        Cursor cursor = DBI.getdata();
        if(cursor.getCount()==0) {
            Toast.makeText(InventoryActivity.this, "No Entries exists", Toast.LENGTH_SHORT).show();
        } else {
            while(cursor.moveToNext()) {
                name.add(cursor.getString(0));
                quantity.add(cursor.getString(1));
            }
        }
    }

    public static void smsEnabled() {
        smsauth = true;
    }
    public static void smsDisabled() {
        smsauth = false;
    }
    public static void sendSMS(Context context) {
        String phone = "+1-555-521-5554";
        String message = "Test message";

        if(smsauth) {
            SmsManager sms = SmsManager.getDefault();
            sms.sendTextMessage(phone, null, message, null, null);
            Toast.makeText(context, "Message sent", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "SMS Disabled", Toast.LENGTH_SHORT).show();
        }
    }

}