package com.cs360.andrewmcpherson_inventoryapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Toast;

public class PermissionActivity extends AppCompatActivity implements CompoundButton.OnCheckedChangeListener {
    private final int REQUEST_SEND_SMS = 0;
    private static final String TAG = "SmsNotificationsActivity";
    //private final int MY_PERMISSIONS_REQUEST_SEND_SMS = 0;

    EditText phoneNum;
    SwitchCompat switchCompat;

    Boolean switchBool = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permission);
        phoneNum = findViewById(R.id.inputPhoneNumber);
        switchCompat = findViewById(R.id.switchPermission);
        //checkForSmsPermission();

        switchCompat.setChecked(switchBool);
        switchCompat.setOnCheckedChangeListener(this );
        }

    @Override
    public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
        if(switchCompat.isChecked()) {
            Toast.makeText(this, "App Permissions Enabled", Toast.LENGTH_SHORT).show();
            InventoryActivity.smsEnabled();
            //phoneNum.setEnabled(true);
        } else {
            Toast.makeText(this, "App Permissions Disabled", Toast.LENGTH_SHORT).show();
            InventoryActivity.smsDisabled();
            //phoneNum.setEnabled(false);
            //phoneNum.getText().clear();
        }
        finish();
    }
        /*
    private void checkForSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)!= PackageManager.PERMISSION_GRANTED) {
            //Log.d(TAG, getString(R.string.permission_not_granted));
            //ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.SEND_SMS},MY_PERMISSIONS_REQUEST_SEND_SMS);
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS)) {
            //requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, MY_PERMISSIONS_REQUEST_SEND_SMS)) {
                Toast.makeText(this, "Permissions are disabled", Toast.LENGTH_SHORT).show();
            } else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, MY_PERMISSIONS_REQUEST_SEND_SMS);
            }
        } else {
            Toast.makeText(this, "Permissions are enabled", Toast.LENGTH_SHORT).show();
            //Log.d(TAG, getString(R.string.permission_granted));

        }
        //Intent intent = new Intent(getApplicationContent(),.class);
        //startActivity(intent);
    }
    */


}